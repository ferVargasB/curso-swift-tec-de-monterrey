//: Mini reto 2


// Una enumeracion con 4 estados

enum Velocidades: Int {
    case Apagado = 0
    case VelocidadBaja = 20
    case VelocidadMedia = 50
    case VelocidadAlta = 120
    
    init(){
        self = .Apagado
    }
}

class Auto {
    var velocidad = Velocidades()
    
    init(){
        self.velocidad = .Apagado
    }
    
    func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena: String) {
        switch velocidad {
        case .Apagado:
            self.velocidad = .VelocidadBaja
            return (0, "Apagado")
        case .VelocidadBaja:
            self.velocidad = .VelocidadMedia
            return (20, "Velocidad baja")
        case .VelocidadMedia:
            self.velocidad = Velocidades.VelocidadAlta
            return (50, "Velocidad media")
        case .VelocidadAlta:
            self.velocidad = .VelocidadMedia
            return (120, "Velocidad alta")
        default:
            return (1, "Error")
        }
    }
}

var chevy = Auto()

for contador in 1...20{
    print(chevy.cambioDeVelocidad())
}
