/*
  Tienes que generar una serie de números de 100 números, del 0 al 100, tienes que incluir el 100. Y cada vez que imprimas ese número tienes que decidir cómo lo imprimes de acuerdo a las siguientes cuatro reglas. Si el número es divisible entre cinco, debes de imprimir el número y la palabra Bingo. Si el número es par, debes imprimir el número, más la palabra Par. Si el número es impar, debes imprimir el número y la palabra impar. Si el número se encuentra entre un rango de 30 a 40, vamos a imprimir el número, más la palabra Viva Swift.
 */


for indice in 1...100{
    
    var numero : Int = indice
    var numeroDivisibleEntreDos = numero % 2
    var numeroDivisibleEntreCinco = numero % 5
    
    
    if numeroDivisibleEntreDos == 0 {
        print("El número \(indice) es Par")
    } else if numeroDivisibleEntreCinco == 0 {
        print("El número \(indice) BINGO!!!")
    } else {
        print("El número \(indice) es Impar")
    }
    
    switch numero {
    case 30...40:
        print("El número \(indice) Viva Swift")
    default:
        print("El número \(indice) es Impar")
    }
}
